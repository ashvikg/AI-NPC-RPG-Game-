# Brindlewood: The Awakening — Advanced RPG v0.3

This upgrade preserves the v0.2 FastAPI dialogue service and Unity integration while expanding the browser prototype.

## Added in v0.3
- Health, gold, potion, XP and level HUD
- Inventory with Ancient Sigil, Village Token and Wraith Essence
- Quest progression: accept quest, collect sigil, report to Mira, defeat Forest Wraith
- SPACE combat with enemy health and retaliation
- H healing potion (+35 HP)
- Autosave/load of quest, player position, health, currency, XP, inventory and combat state in browser local storage
- Persistent browser session ID for backend NPC conversation memory

## Windows quick start

Terminal 1 — backend:
```powershell
cd AI-NPC-RPG\backend
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item .env.example .env
python -m uvicorn app.main:app --reload
```

Terminal 2 — frontend:
```powershell
cd AI-NPC-RPG\frontend
python -m http.server 5500
```
Open http://127.0.0.1:5500. Keep both terminals running.

## Controls
| Key | Action |
|---|---|
| W A S D / arrows | Move |
| E | Talk / interact / collect |
| SPACE | Attack the Forest Wraith |
| H | Use a healing potion |
| Click NPC | Select NPC |

## Quest walkthrough
1. Move close to Elder Mira and press E.
2. Find the glowing Ancient Sigil in the north and press E.
3. Return to Mira and press E to receive a Village Token and 15 gold.
4. Move close to the Forest Wraith by the eastern pond and press SPACE three times.
5. The Wraith retaliates; press H to restore up to 35 HP.

## Optional AI dialogue
Edit `backend/.env` and set `AI_API_KEY`, `AI_BASE_URL`, and `AI_MODEL`. Keep provider secrets on the backend; never put them in frontend JavaScript or commit `.env`. Without a key, local fallback dialogue works.

## Save data
Game progress is stored in the browser's local storage on the same browser/device. Use NEW SESSION to reset it.

## Existing Unity integration
The original `unity/Assets/Scripts/` files are preserved. The v0.3 gameplay additions are in the browser prototype; they are not automatically ported into a Unity scene.

## Prototype limitations
This remains a 2D browser prototype. It does not yet include advanced collision/pathfinding, sound, multiplayer, cloud saves, player accounts, or a complete Unity scene. Restrict CORS and add authentication/rate limiting before public deployment.
